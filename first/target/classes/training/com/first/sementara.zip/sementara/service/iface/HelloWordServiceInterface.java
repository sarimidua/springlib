package training.com.first.service.iface;

import training.com.first.model.UserModel;

public interface HelloWordServiceInterface {

	public String getOutput();
	public String getOutput(String inputan);
	public String getOutput(String gender, String inputan, String title);
	public Iterable<UserModel> getOutputFromDatabase();
}
