package training.com.first.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import training.com.first.model.UserModel;
import training.com.first.repository.iface.RoleRepositoryInterface;
import training.com.first.service.iface.HelloWordServiceInterface;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class HelloWordServiceImplement implements HelloWordServiceInterface{

	@Autowired
	private RoleRepositoryInterface repo;
	
	@Override
	public String getOutput() {
		// TODO Auto-generated method stub
		return "hello word";
	}

	@Override
	public String getOutput(String inputan) {
		// TODO Auto-generated method stub
		return "hello word "+inputan;
	}

	@Override
	public String getOutput(String gender, String inputan, String title) {
		// TODO Auto-generated method stub
		return "hello word "+gender+" "+inputan+" "+title;
	}

	@Override
	public Iterable<UserModel> getOutputFromDatabase() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

}
