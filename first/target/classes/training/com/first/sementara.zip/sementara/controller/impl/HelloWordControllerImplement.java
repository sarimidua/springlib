package training.com.first.controller.impl;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.UnsupportedJwtException;
import training.com.first.controller.iface.HelloWordControllerInterface;
import training.com.first.service.iface.HelloWordServiceInterface;

@RestController
public class HelloWordControllerImplement implements HelloWordControllerInterface{

	@Autowired
	private HelloWordServiceInterface service;
	
	@Override
	public ResponseEntity<?> getOutput(HttpServletRequest req, HttpServletResponse response)
			throws ExpiredJwtException, UnsupportedJwtException, MalformedJwtException, SignatureException,
			IllegalArgumentException, UnsupportedEncodingException {
		// TODO Auto-generated method stub
		return ResponseEntity.ok(service.getOutput());
	}

	@Override
	public ResponseEntity<?> getOutput(@PathVariable String inputan, HttpServletRequest req, HttpServletResponse response)
			throws ExpiredJwtException, UnsupportedJwtException, MalformedJwtException, SignatureException,
			IllegalArgumentException, UnsupportedEncodingException {
		// TODO Auto-generated method stub
		return ResponseEntity.ok(service.getOutput(inputan));
	}

	@Override
	public ResponseEntity<?> getOutput(@PathVariable String inputan, HttpServletRequest req, 
			@RequestParam("title") String title, @RequestParam("gender") String gender,
			HttpServletResponse response) throws ExpiredJwtException, UnsupportedJwtException, MalformedJwtException,
			SignatureException, IllegalArgumentException, UnsupportedEncodingException {
		// TODO Auto-generated method stub
//		return ResponseEntity.ok(service.getOutput(gender, inputan, title));
		return ResponseEntity.status(503).body(service.getOutput(gender, inputan, title));
	}

	@Override
	public ResponseEntity<?> getOutputFromDatabase(HttpServletRequest req, HttpServletResponse response)
			throws ExpiredJwtException, UnsupportedJwtException, MalformedJwtException, SignatureException,
			IllegalArgumentException, UnsupportedEncodingException {
		// TODO Auto-generated method stub
		return ResponseEntity.ok(service.getOutputFromDatabase());
	}

}
